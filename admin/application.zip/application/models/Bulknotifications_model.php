<?php 
class Bulknotifications_model extends CI_Model {
    public function _consruct(){
        parent::_construct();
    }


 

    
}
