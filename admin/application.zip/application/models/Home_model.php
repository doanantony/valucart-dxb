<?php 
class Home_model extends CI_Model {
    public function _consruct(){
        parent::_construct();
    }

    function get_user_list(){
    	$user_type = array(
    					array(	
    						'id'=>2,
    					   	'table'=>'company',
    					   	'user'=>'company',
    					   	'label'=>'Merchant'
    					),
    					array(	
    						'id'=>3,
    					   	'table'=>'portal_users',
    					   	'user'=>'portal_users',
    					   	'label'=>'Portal User'
    					),
    					array(	
    						'id'=>4,
    					   	'table'=>'app_customer',
    					   	'user'=>'app_users',
    					   	'label'=>'App User'
    					),
    					array(	
    						'id'=>5,
    					   	'table'=>'drivers',
    					   	'user'=>'fleet_drivers',
    					   	'label'=>'Drivers'
    					),
    					array(	
    						'id'=>6,
    					   	'table'=>'technician',
    					   	'user'=>'technician',
    					   	'label'=>'Technicians'
    					),
    					array(	
    						'id'=>7,
    					   	'table'=>'sales_users',
    					   	'user'=>'sales_users',
    					   	'label'=>'Sales Users'
    					),
    					array(	
    						'id'=>8,
    					   	'table'=>'company_users',
    					   	'user'=>'company_users',
    					   	'label'=>'Company Users'
    					),
    				);
    	$users = array();
    	foreach ($user_type as $rs) {
    		$total = $this->db->where('status!=2')->get($rs['table'])->num_rows();    		
          //  echo $this->db->last_query();die;
    		$user = $rs['user'];
    		$users[$user] = $total;
    	}
    	return $users;

    }

    function get_card_info(){
        $remaining = 0;
        

    	$issued = $this->db->select_sum('issued_cards')->get('issued_cards')->row();
    	$actived = $this->db->query("SELECT COUNT(DISTINCT case when active_cards.status = 1 then active_cards.cards_id end) as active, COUNT(DISTINCT case when active_cards.status = 0 then active_cards.cards_id end) as suspend, COUNT(DISTINCT active_cards.cards_id) AS total_cards from active_cards group by active_cards.status")->row();
        if($actived){
            $remaining = $issued->issued_cards - $actived->total_cards;
        } else {
            $actived = (object) array('active'=>0,
                        'suspend'=>0);
        }
    	
    	$topup = $this->db->query("SELECT COUNT(id) AS topup_count,IFNULL(SUM(amount),0) AS amount FROM `card_topup`")->row();
    	$card_type = $this->db->query("SELECT COUNT(DISTINCT case when active_cards.card_type_id = 1 then active_cards.cards_id end) as jordan, COUNT(DISTINCT case when active_cards.card_type_id = 2 then active_cards.cards_id end) as student, COUNT(DISTINCT case when active_cards.card_type_id = 3 then active_cards.cards_id end) as refugee,COUNT(DISTINCT case when active_cards.card_type_id = 4 then active_cards.cards_id end) as elder from active_cards")->row();

    	$array = array('issued_cards'=>$issued->issued_cards!=null?$issued->issued_cards:0,
    				   'active_cards'=>$actived->active,
    				   'suspend_cards'=>$actived->suspend,
    				   'remaining_cards'=>$remaining,
    				   'topup_count'=>$topup->topup_count,
    				   'topup_amount'=>$topup->amount,
    				   'jordan'=>$card_type->jordan,
    				   'student'=>$card_type->student,
    				   'refugee'=>$card_type->refugee,
    				   'elder'=>$card_type->elder
    				  );
    	return $array;    	
    }

    function get_chart_info(){
        $chart_rs = array();
        $chart_array = $this->db->query("SELECT calendar.calendar_date AS transact_date, COALESCE(SUM(transactions.fare_applied),0) AS total FROM calendar LEFT JOIN transactions ON transactions.transact_date = calendar.calendar_date WHERE calendar.calendar_date BETWEEN DATE_SUB(CURDATE(),INTERVAL 7 DAY) AND CURDATE() GROUP BY calendar.calendar_date")->result();

        foreach ($chart_array as $res) {
            $chart_rs[] = array(
            					'year'=>$res->transact_date,
                                'value'=>$res->total
                            );
        }

        if(count($chart_rs)==0){
            $chart_rs[] = array('year'=>date('Y-m-d'),
                                'value'=>0);
        }

        return $chart_rs;
    }

    function get_terminal_info(){
    	$rs = $this->db->query("SELECT terminals.current_lat,terminals.current_lng,terminals.terminal_name,terminals.id FROM driver_trips INNER JOIN terminals ON driver_trips.terminal_id = terminals.id WHERE driver_trips.status = 1")->result();

    	return $rs;
    }

    function get_transaction_info(){

    	$rs = $this->db->query("SELECT COUNT(DISTINCT case when transactions.status = 1 then transactions.id end) as success, COUNT(DISTINCT case when transactions.status = 0 then transactions.id end) as insufficent, COUNT(DISTINCT transactions.id) AS total, CONCAT(COALESCE(SUM(DISTINCT case when transactions.status = 1 then transactions.fare_applied end),0),' JD') AS total_amount from transactions group by transactions.status")->row();        
        if(count($rs)==0){
            $rs = (object) array('success'=>0,'insufficent'=>0,'total'=>0,'total_amount'=>'0 JD');
        }

        return $rs;


    }

    function get_bundles(){
        
        $query = $this->db->limit(4); 
        $query = $this->db->order_by("id","desc")->get('bundles');
        $result = $query->result();
        return $result;
    }


    function get_orders(){
        
        $query = $this->db->limit(5); 
        $query = $this->db->order_by("id","desc")->get('orders');
        $result = $query->result();
        return $result;
    }



}
?>