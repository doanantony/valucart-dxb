<?php 
class Vendors_model extends CI_Model {
    public function _consruct(){
        parent::_construct();
    }

    function get_products(){
        
        $query = $this->db->limit(4); 
        $query = $this->db->order_by("id","desc")->get('products');
        $result = $query->result();
        return $result;
    }

    function get_orders(){
        
        $query = $this->db->limit(5); 
        $query = $this->db->order_by("id","desc")->get('orders');
        $result = $query->result();
        return $result;
    }




    function save_vendors($data,$object_id) {

        $name = $data['name'];
        $this->db->where('name', $name);
        $this->db->from('vendors');
        $count = $this->db->count_all_results();
        $data['created_at'] = date("Y-m-d H:i:s");
        $data['updated_at'] = date("Y-m-d H:i:s");
        if($count > 0) {
            return "Exist";
        }
        else {
            
            $vendor_data = array(
                                'name' => $data['name'],
                                'email' => $data['email'],
                                'latitude' => $data['latitude'],
                                'user_type_id' => 5,
                                'created_at' => $data['created_at'],
                                'updated_at' => $data['updated_at']

                            );


            $result = $this->db->insert('departments', $vendor_data); 

            $user_ip = get_client_ip();
            $insert_id = $this->db->insert_id();


                $rs = array(
                        'company_id' => '1',
                        'user_id' => $insert_id,
                        'user_type_id' => '5',
                        'username' => $data['username'],
                        'passwd' => md5($data['password']));

            $this->db->insert('users', $rs); 


            $log = array(
                         'id' =>$insert_id,
                         'log' => 'Created Vendor '.$data['name']. ''
                      );

            $session_data = $this->session->userdata('logged_in');

            $res = updatelog($log,$session_data);


            if($res) {
                return $insert_id;
            }
            else {
                return "Error";
            }
        }
    }



    function get_single_vendors($id) {
        $query = $this->db->where('id', $id);
        $query = $this->db->get('vendors');
        $result = $query->row();
        return $result;
    } 



    function update_vendors($data, $id,$object_id) {
         
       
        $name = $data['name'];
        $this->db->where('name', $name);
        $this->db->where("id !=",$id);
        $this->db->from('vendors');
        $count = $this->db->count_all_results();
        $data['updated_at'] = date("Y-m-d H:i:s");
        if($count > 0) {
            return "Exist";
        }
        else {



            $vendor_data = array(
                                'name' => $data['name'],
                                'short_name' => $data['short_name'],
                                'user_type_id' => 5,
                                'email' => $data['email'],
                                'updated_at' => $data['updated_at']

                            );



            $this->db->where('id',$id);
            $result = $this->db->update('vendors', $vendor_data); 



                        $where = array('company_id' => '1',
                            'user_id' => $id,
                            'user_type_id' => '5');

            $rs = array('username' => $data['username'],
                       // 'passwd' => md5($data['password'])
                    );
            $this->db->where($where)->update('users', $rs); 




            $log = array(
                         'id' =>$id,
                         'log' => 'Updated Vendors '.$data['name']. ''
                      );

            $session_data = $this->session->userdata('logged_in');

            $res = updatelog($log,$session_data);

            if($res) {
                return "Success";
            }
            else {
                return "Error";
            }
        }
    }




















    function save_tech($data,$object_id) {
        
        $this->db->where('email', $data['email']);
        $this->db->or_where('phone_no',$data['phone_no']);
        $this->db->from('techteam');
        $count = $this->db->count_all_results();

        $this->db->where('username', $data['username']);
        $this->db->from('users');
        $count_user = $this->db->count_all_results();


        if($count > 0 || $count_user >  0) {
            return "Exist";
        }
        else {
            $user_ip = get_client_ip();
            $date_time = date('Y-m-d H:i:s');
            $session_data = $this->session->userdata('logged_in');
            $tech_data = array(
                                    'first_name' => $data['first_name'], 
                                    'last_name' => $data['last_name'], 
                                    'email' => $data['email'], 
                                    'phone_no' => $data['phone_no'], 
                                    'status' => $data['status']!=''?$data['status']:1, 
                                    'created_at' => $date_time,
                                    'updated_at' => $date_time
                                    );
          
            $this->db->insert('techteam', $tech_data); 

            $insert_id = $this->db->insert_id();
            $session_data = $this->session->userdata('logged_in');
            
            // $where = array('company_id' => '1',
            //                 'user_id' => $insert_id,
            //                 'user_type_id' => '2');

            $rs = array(
                        'company_id' => '1',
                        'user_id' => $insert_id,
                        'user_type_id' => '6',
                        'username' => $data['username'],
                        'passwd' => md5($data['password']));
            $this->db->insert('users', $rs); 


            
                    $log = array(
                         'id' =>$insert_id,
                         'log' => 'Created IT Member '.$data['first_name']. ''
                      );

            $session_data = $this->session->userdata('logged_in');
            $res = updatelog($log,$session_data);


            if($res) {
                return "Success";
            }
            else {
                return "Error";
            }
        }
    }


    function get_single_tech($id) {
        $query = $this->db->where('id', $id);
        $query = $this->db->get('techteam');
        $result = $query->row();
        return $result;
    }   


    function update_tech($data, $id,$object_id) {
        $this->db->where("id !=",$id);
        $this->db->where(" (`email` = '".$data['email']."' OR `phone_no` = '".$data['phone_no']."')" );
        //$this->db->or_where('phone_no',$data['phone_no']);
        $this->db->from('techteam');
       
        $count = $this->db->count_all_results();
        if($count > 0) {
            return "Exist";
        }
        else {
            $user_ip = get_client_ip();
            $date_time = date('Y-m-d H:i:s');
            $session_data = $this->session->userdata('logged_in');
            $tech_data = array(
                                    'first_name' => $data['first_name'], 
                                    'last_name' => $data['last_name'], 
                                    'email' => $data['email'], 
                                    'phone_no' => $data['phone_no'], 
                                    'status' => $data['status'], 
                                    'user_act_id' => $session_data['id'],
                                    'updated_at' => $date_time
                                    );
            $this->db->where('id',$id);
            $this->db->update('techteam', $tech_data); 
            $where = array('company_id' => '1',
                            'user_id' => $id,
                            'user_type_id' => '6');
            $rs = array('username' => $data['username'],
                       // 'passwd' => md5($data['password'])
                    );
            $this->db->where($where)->update('users', $rs); 




            
                    $log = array(
                         'id' =>$id,
                         'log' => 'Updated IT Member '.$data['first_name']. ''
                      );

            $session_data = $this->session->userdata('logged_in');
            $res = updatelog($log,$session_data);


            if($res) {
                return "Success";
            }
            else {
                return "Error";
            }
        }
    }

    
}
